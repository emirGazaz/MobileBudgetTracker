package com.example.hw1_emiryamangazaz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.hw1_emiryamangazaz.databinding.ActivityIncomeBinding
import java.time.LocalDate
import java.util.Date

class ActivityIncome : AppCompatActivity() {

    private lateinit var binding: ActivityIncomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityIncomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pastIn = intent.getStringExtra("pastIn")
        val pastAct = intent.getStringExtra("pastAct")
        val currentValue = intent.getStringExtra("currentValue")

        binding.curView.text = "$currentValue ₺"

        binding.btnFinish.setOnClickListener {
            val resultIntent = Intent()
            val newCur = currentValue.toString().toDouble() + binding.editAmount.text.toString().toDouble()
            resultIntent.putExtra("stringAdd", "INCOME : +${binding.editAmount.text.toString()} ₺\n Date : ${LocalDate.now()}\n Current Value : $newCur\n\n")
            resultIntent.putExtra("inAmount", binding.editAmount.text.toString())
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}
