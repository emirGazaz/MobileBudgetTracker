package com.example.hw1_emiryamangazaz

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.hw1_emiryamangazaz.databinding.ActivityExpenseBinding
import com.google.android.material.snackbar.Snackbar
import java.time.LocalDate
import kotlin.math.exp

class ActivityExpense : AppCompatActivity() {
    lateinit var expenseBinding: ActivityExpenseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_expense)

        expenseBinding = ActivityExpenseBinding.inflate(layoutInflater)
        setContentView(expenseBinding.root)

        val pastOut = intent.getStringExtra("pastOut")
        val pastAct = intent.getStringExtra("pastAct")
        val currentValue = intent.getStringExtra("currentValue")

        expenseBinding.curView.text = "$currentValue ₺"

        expenseBinding.btnFinish.setOnClickListener {
            val resultIntent = Intent()
            if(!expenseBinding.editAmount.text.isBlank()){
                try {
                    val newCur = currentValue.toString().toDouble() - expenseBinding.editAmount.text.toString().toDouble()
                    if(expenseBinding.editAmount.text.toString().toDouble()<0){
                        showSnackbar()
                    }else {
                        if (newCur < 0) {
                            val builder = AlertDialog.Builder(this)
                            builder.setTitle("Budget Exceeded!")
                            builder.setMessage("You cannot perform this operation.")

                            builder.setPositiveButton("OK") { dialog, _ ->
                                expenseBinding.editAmount.setText("")
                                dialog.dismiss()
                            }


                            val dialog = builder.create()
                            dialog.show()

                        } else {
                            resultIntent.putExtra(
                                "stringAdd",
                                "EXPENSE : -${expenseBinding.editAmount.text.toString()} ₺\n Date : ${LocalDate.now()}\n Current Value : $newCur\n\n"
                            )
                            resultIntent.putExtra(
                                "outAmount",
                                expenseBinding.editAmount.text.toString()
                            )
                            setResult(Activity.RESULT_OK, resultIntent)
                            finish()
                        }
                    }
                }catch (e : NumberFormatException){
                    showSnackbar()
                }
            }else{
                finish()
            }
        }

        expenseBinding.btnBack.setOnClickListener {
            finish()
        }

        expenseBinding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                expenseBinding.editAmount.setText(progress.toString())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Called when the user first touches the SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Called when the user stops touching the SeekBar
            }
        })

    }

    fun showSnackbar(){
        Snackbar.make(expenseBinding.root, "You must enter a positive number as amount", Snackbar.LENGTH_SHORT)
            .setAction("OK") {
                expenseBinding.editAmount.setText("")
            }
            .show()
    }
}