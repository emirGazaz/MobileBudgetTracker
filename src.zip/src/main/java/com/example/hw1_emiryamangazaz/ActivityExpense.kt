package com.example.hw1_emiryamangazaz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.hw1_emiryamangazaz.databinding.ActivityExpenseBinding
import java.time.LocalDate
import kotlin.math.exp

class ActivityExpense : AppCompatActivity() {
    lateinit var expenseBinding: ActivityExpenseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_expense)

        expenseBinding = ActivityExpenseBinding.inflate(layoutInflater)
        setContentView(expenseBinding.root)

        val pastOut = intent.getStringExtra("pastOut")
        val pastAct = intent.getStringExtra("pastAct")
        val currentValue = intent.getStringExtra("currentValue")

        expenseBinding.curView.text = "$currentValue ₺"

        expenseBinding.btnFinish.setOnClickListener {
            val resultIntent = Intent()
            val newCur = currentValue.toString().toDouble() - expenseBinding.editAmount.text.toString().toDouble()
            resultIntent.putExtra("stringAdd", "EXPENSE : -${expenseBinding.editAmount.text.toString()} ₺\n Date : ${LocalDate.now()}\n Current Value : $newCur\n\n")
            resultIntent.putExtra("outAmount", expenseBinding.editAmount.text.toString())
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }

        expenseBinding.btnBack.setOnClickListener {
            finish()
        }

    }
}