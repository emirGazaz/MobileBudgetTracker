package com.example.hw1_emiryamangazaz

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.AdapterView
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import android.view.animation.Animation
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.hw1_emiryamangazaz.databinding.ActivityMainBinding
import java.nio.BufferUnderflowException

class MainActivity : AppCompatActivity() {

    lateinit var mainBind : ActivityMainBinding

    var pastActReport : String = ""
    var pastIn : String = ""
    var pastOut : String = ""
    var currentValue : Double = 0.0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val blinkAnimation = AlphaAnimation(1.0f, 0.5f)
        blinkAnimation.duration = 500
        blinkAnimation.repeatMode = Animation.REVERSE
        blinkAnimation.repeatCount = Animation.INFINITE

        mainBind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBind.root)

        mainBind.textCurrent.setText(currentValue.toString() + " ₺")
        mainBind.btnExpense.startAnimation(blinkAnimation)
        mainBind.btnIncome.startAnimation(blinkAnimation)
        mainBind.textCurrent.startAnimation(blinkAnimation)
        renderReport(pastActReport)

        mainBind.spnHist.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedItem = parent?.getItemAtPosition(position).toString()
                if(selectedItem.equals("All Operations")){
                    renderReport(pastActReport)
                }else if(selectedItem.equals("Incomes Only")){
                    renderReport(pastIn)
                }else{
                    renderReport(pastOut)
                }

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }

        mainBind.btnIncome.setOnClickListener {
            val inAct : Intent
            inAct = Intent(this, ActivityIncome::class.java)
            val b = Bundle()
            b.putString("currentValue",currentValue.toString())
            b.putString("pastIn", pastIn)
            b.putString("pastActReport", pastActReport)
            inAct.putExtras(b)
            inActForResult.launch(inAct)
        }

        mainBind.btnExpense.setOnClickListener {
            val inAct : Intent
            inAct = Intent(this, ActivityExpense::class.java)
            val b = Bundle()
            b.putString("currentValue",currentValue.toString())
            b.putString("pastOut", pastIn)
            b.putString("pastActReport", pastActReport)
            inAct.putExtras(b)
            exActForResult.launch(inAct)
        }

    }

    var inActForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ result ->
        if(result.resultCode == RESULT_OK){
            val receivedString = result.data!!.getStringExtra("stringAdd")
            val addAmount = result.data!!.getStringExtra("inAmount")
            pastIn += " " + receivedString
            pastActReport += " " + receivedString
            currentValue += addAmount!!.toDouble()
            mainBind.textCurrent.text = "$currentValue ₺"
            renderReport(pastActReport)
        }

    }

    var exActForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ result ->
        if(result.resultCode == RESULT_OK && result.data!!.getStringExtra("outAmount").toString().toDouble() <= currentValue){
            val receivedString = result.data!!.getStringExtra("stringAdd")
            val outAmount = result.data!!.getStringExtra("outAmount").toString().toDouble()
            pastOut += " " + receivedString
            pastActReport += " " + receivedString
            currentValue -= outAmount
            mainBind.textCurrent.text = "$currentValue ₺"
            renderReport(pastActReport)
        }

    }

    fun renderReport(str : String){
        if(str.isBlank()) {
            mainBind.textPast.setText("No past activity found.")
        }else{
            mainBind.textPast.setText(str)
        }
    }
}